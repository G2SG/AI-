
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <png.h>
#include "procpng.h"


png_minfo_t* read_png(char *file){
   png_byte signature[8] = { 0, };
   png_minfo_t *pinfo = NULL;

   FILE *fp = fopen(file, "rb");
   if(!fp){
      printf("error: can not open file[%s].\n", file);
      return NULL;
   }
		
   // signature read, check png signature
   fread(signature, 1, sizeof(signature), fp);
   if(png_sig_cmp(signature, 0, sizeof(signature)) != 0){
      printf("error: file [%s] is not png.\n", file);
      fclose(fp);
      return NULL;
   }

   // init png struct pointer
   png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
   if(!png_ptr){
      printf( "error: png_create_read_struct faild\n" );
      fclose(fp);
      return NULL;
   }

   png_infop info_ptr = png_create_info_struct(png_ptr);
   if(!info_ptr){
      printf("error: png_create_info_struct faild\n");
      png_destroy_read_struct(&png_ptr, NULL, NULL);
      fclose(fp);
      return NULL;
   }

   png_infop end_info = png_create_info_struct(png_ptr);
   if(!end_info){
      printf( "error: png_create_info_struct [end_info]\n");
      png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
   }

   if(setjmp(png_jmpbuf(png_ptr))){
      printf( "error: during init_io\n" );
      png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
      fclose(fp);
      return NULL;
   }

   // reading png file info IHDR
   png_init_io(png_ptr, fp);
   png_set_sig_bytes(png_ptr, sizeof(signature));
   png_read_info(png_ptr, info_ptr);
   png_uint_32 width = png_get_image_width(png_ptr, info_ptr);
   png_uint_32 height = png_get_image_height(png_ptr, info_ptr);
   // color: 0(grayscale), 2(truecolor), 3(indexed with palette)
   //        4(grayscale with alpha), 5(truecolor with alpha)
   png_byte color_type = png_get_color_type(png_ptr, info_ptr);
   png_byte bit_depth = png_get_bit_depth(png_ptr, info_ptr);

   int pass = png_set_interlace_handling(png_ptr);
   png_read_update_info(png_ptr, info_ptr);

   //printf("width:%d, height:%d, color:%d, depth:%d\n",
   //   width, height, (int)color_type, (int)bit_depth);

   //if(png_get_color_type(png_ptr, info_ptr) != PNG_COLOR_TYPE_RGBA){
   //   printf( "error: file color type must be PNG_COLOR_TYPE_RGBA\n" );
   //   png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
   //   fclose(fp);
   //   return NULL;
   //}

   // create minimal info struct
   pinfo = (png_minfo_t*)malloc(sizeof(png_minfo_t));
   pinfo->width = width;
   pinfo->height = height;
   pinfo->buf = (png_bytepp)png_malloc(png_ptr, sizeof(png_bytep) * height);

   // reading image data
   if(setjmp(png_jmpbuf(png_ptr))){
      printf("error: read image\n");
      png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
      fclose(fp);
      return NULL;
   }

   //png_size_t wsize = width * sizeof(png_rgba_pixel_t);
   for(int y=0; y<height; y++){
      pinfo->buf[y] = (png_bytep)png_malloc(png_ptr, png_get_rowbytes(png_ptr, info_ptr));
   }
   //png_set_rows(png_ptr, info_ptr, pinfo->buf);
   png_read_image(png_ptr, pinfo->buf);
   png_read_end(png_ptr, end_info);

   // free pointer
   png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
   fclose(fp);

   return pinfo;
}

void free_png_minfo(png_minfo_t *minfo){
   if(minfo){
      if(minfo->buf){
         for(int y=0; y<minfo->height; y++){
            if(minfo->buf[y]){
               free(minfo->buf[y]);
            }
         }
         free( minfo->buf );
      }
      free( minfo );
   }
}


