
#ifndef __PROCPNG_H__
#define __PROCPNG_H__

#include <png.h>

typedef struct png_minimal_info{
   png_uint_32 width;
   png_uint_32 height;
   png_bytepp buf;
}png_minfo_t;

typedef struct _png_rgba_pixel{
   png_byte red;
   png_byte green;
   png_byte blue;
   png_byte alpha;
}png_rgba_pixel_t;

png_minfo_t* read_png(char *file);
void free_png_minfo(png_minfo_t *minfo);

#endif   // __PROCPNG_H__
