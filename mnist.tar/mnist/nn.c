
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <dirent.h>
#include "procpng.h"

#define MAXIL 784
#define MAXHL 100
#define MAXOL 10

int compextension(const struct dirent *info){
   char *exten;

   exten = strrchr((char*)info->d_name, '.');
   if(exten == NULL) return 0;

   if(strcmp(exten, ".png") == 0) return 1;
   else return 0;
}

float sigmoid(float x){
   return 1 / ( 1 + expf(-x));
}

float diffsigmoid(float x){
   float y;
   y = 1 / (1 + expf(-x));
   return (y * (1 - y));
}

float relu(float x){
   return (x <= 0.0)? 0.0: x;
}

float diffrelu(float x){
   return (x <= 0.0)? 0.0: 1.0;
}

void main(){
   int m, n;
   char dirname[128];
   char fname[256];
   int index;
   int iter;
   //int fcount;
   int fcount[10];
   //struct dirent **namelist;
   struct dirent **namelist[10];
   png_minfo_t *pinfo;
   int ll;   // lerning loop
   int nil, nhl, nol;   // number of input, hidden, output layer
   float lr;   // learning rate
   float in[MAXIL];
   float w1[MAXIL][MAXHL];
   float hl[MAXHL];   // hdden layer
   float ho[MAXHL];   // output of hidden layer
   float w2[MAXHL][MAXOL];
   float ol[MAXOL];   // output layer
   float oo[MAXOL];   // output of output layer
   float b1[MAXIL][MAXHL];   // back propagation for hidden layer
   float b2[MAXOL];   // back propagation for output layer
   float bp[MAXHL];
   float target[MAXOL];
   float loss[MAXOL];

   sprintf(dirname, "/root/work/mnist_png/training");

   for(m=0; m<10; m++){
      sprintf(fname, "%s/%d", dirname, m);
      fcount[m] = scandir(fname, &namelist[m], compextension, alphasort);
   }

   sprintf(fname, "%s/0/%s", dirname, namelist[0][0]->d_name);
   printf("fcount:%d, %s\n", fcount[0], fname);

   pinfo = (png_minfo_t*)read_png(fname);
   printf("width:%d, height:%d\n", pinfo->width, pinfo->height);
   for(m=0; m<pinfo->height; m++){
      for(n=0; n<pinfo->width; n++){
         in[(m*pinfo->width)+n] = (float)pinfo->buf[m][n] / 255.0;   // grayscale(0-255)
         if(pinfo->buf[m][n])
            printf("1");
         else
            printf("0");
      }
      printf("\n");
   }

   nil = MAXIL;
   nhl = MAXHL;
   nol = MAXOL;

   lr = 0.1;

   srand((unsigned int)(time(0)));
   for(m=0; m<nil; m++){
      for(n=0; n<nhl; n++){
         //w1[m][n] = (float)(abs(rand()) / (RAND_MAX + 1.0)) / 100.0;
         w1[m][n] = (float)(abs(rand()-(RAND_MAX/2)) / (RAND_MAX + 1.0)) / 100.0;
         //printf("w1:%f\n", w1[m][n]);
      }
   }
   for(m=0; m<nhl; m++){
      for(n=0; n<nol; n++){
         //w2[m][n] = (float)(abs(rand()) / (RAND_MAX + 1.0)) / 100.0;
         w2[m][n] = (float)(abs(rand()-(RAND_MAX/2)) / (RAND_MAX + 1.0)) / 100.0;
         //printf("w2:%f\n", w2[m][n]);
      }
   }

   for(iter=0; iter<5000; iter++){
      //index = iter%10;
      //sprintf(fname, "%s/%d", dirname, index);
      //fcount = scandir(fname, &namelist, compextension, alphasort);
      //printf("index[%d], #file in directory:%d\n", index, fcount);

      for(ll=0; ll<10; ll++){
         index = ll;
         sprintf(fname, "%s/%d/%s", dirname, index, namelist[ll][iter]->d_name);
         //exten = strchr((char*)namelist[ll]->d_name, '.');

         //memset(target, 0, MAXOL*sizeof(int));
         //target[index] = 1.0;
         for(m=0; m<nol; m++){
            target[m] = 0.01;
         }
         target[index] = 0.99;

         //printf("%s, index:%d\n", fname, index);
         pinfo = (png_minfo_t*)read_png(fname);
         for(m=0; m<pinfo->height; m++){
            for(n=0; n<pinfo->width; n++){
               //in[(m*pinfo->width)+n] = (float)pinfo->buf[m][n] / 255.0;   // grayscale(0-255)
               in[(m*pinfo->width)+n] = (((float)pinfo->buf[m][n] / 255.0) * 0.99) + 0.01;   // grayscale(0-255)
            }
         }

         for(m=0; m<nhl; m++){
            hl[m] = 0.0;
            for(n=0; n<nil; n++){
               hl[m] += (w1[n][m] * in[n]);
            }
            ho[m] = sigmoid(hl[m]);
         }

         for(m=0; m<nol; m++){
            ol[m] = 0.0;
            for(n=0; n<nhl; n++){
               ol[m] += (w2[n][m] * ho[n]);
            }
            oo[m] = sigmoid(ol[m]);
         }

         for(m=0; m<nol; m++){
            //if(target[m] >= 0.5)
            //   loss[m] = 0.5 * powf(target[m]-oo[m], 2.0);
            //else
            //   loss[m] = -(0.5 * powf(target[m]-oo[m], 2.0));

            //loss[m] = (0.5 * powf(target[m]-oo[m], 2.0));
            loss[m] = (target[m]-oo[m]);
         }

         for(m=0; m<nhl; m++){
            bp[m] = 0.0;
            for(n=0; n<nol; n++){
               bp[m] += (w2[m][n] * diffsigmoid(ol[n]) * loss[n]);
            }
         }

         for(m=0; m<nhl; m++){
            for(n=0; n<nil; n++){
               b1[n][m] = (lr * in[n] * diffsigmoid(hl[m]) * bp[m]);
            }
         }

         for(m=0; m<nil; m++){
            for(n=0; n<nhl; n++){
               w1[m][n] = w1[m][n] + b1[m][n];
            }
         }
         for(m=0; m<nhl; m++){
            for(n=0; n<nol; n++){
               w2[m][n] = w2[m][n] + (lr * ho[m] * diffsigmoid(ol[n]) * loss[n]);;
            }
         }
         free_png_minfo(pinfo);
      }

      for(m=0; m<nol; m++){
         printf("%1.3f(%1.2f), ", oo[m], loss[m]);
      }
      printf("\n");
   }


   // test
   sprintf(dirname, "/root/work/mnist_png/testing");
   for(ll=0; ll<10; ll++){
      index = ll;
      sprintf(fname, "%s/%d", dirname, index);
      fcount[ll] = scandir(fname, &namelist[ll], compextension, alphasort);
      sprintf(fname, "%s/%d/%s", dirname, index, namelist[ll][index]->d_name);
      printf("index[%d], %s\n", index, fname);

      pinfo = (png_minfo_t*)read_png(fname);
      for(m=0; m<pinfo->height; m++){
         for(n=0; n<pinfo->width; n++){
            //in[(m*pinfo->width)+n] = (float)pinfo->buf[m][n] / 256.0;   // grayscale(0-255)
            in[(m*pinfo->width)+n] = (((float)pinfo->buf[m][n] / 256.0) * 0.99) + 0.01;   // grayscale(0-255)
         }
      }

      for(m=0; m<nhl; m++){
         hl[m] = 0.0;
         for(n=0; n<nil; n++){
            hl[m] += (w1[n][m] * in[n]);
         }
         ho[m] = sigmoid(hl[m]);
      }

      for(m=0; m<nol; m++){
         ol[m] = 0.0;
         for(n=0; n<nhl; n++){
            ol[m] += (w2[n][m] * ho[n]);
         }
         oo[m] = sigmoid(ol[m]);
      }

      for(m=0; m<nol; m++){
         printf("%1.3f, ", oo[m]);
      }
      printf("\n");
   }

}

