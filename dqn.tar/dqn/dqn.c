
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define MAXROW 10
#define MAXCOL 10

float sigmoid(float x){
   return 1 / ( 1 + expf(-x));
}

float diffsigmoid(float x){
   float y;
   y = 1 / (1 + expf(-x));
   return (y * (1 - y));
}

float relu(float x){
   return (x <= 0.0)? 0.0: x;
}

float diffrelu(float x){
   return (x <= 0.0)? 0.0: 1.0;
}

void predict(float **w1, float *in, float *out,
   float *ol, int nil, int nol){

   int m, n;

   for(m=0; m<nol; m++){
      ol[m] = 0.0;
      for(n=0; n<nil; n++){
         ol[m] += (w1[n][m] * in[n]);
      }
      //out[m] = sigmoid(ol[m]);
      out[m] = relu(ol[m]);
   }
}

void fit(float *in, float *loss, float **w1,
   float *ol, float lr, int nil, int nol){

   int m, n;

   for(m=0; m<nil; m++){
      for(n=0; n<nol; n++){
         w1[m][n] = w1[m][n] + (lr * in[m] * diffrelu(ol[n]) * loss[n]);
      }
   }
}

void main(){
   int m, n;
   int nil, nol;
   float inp[16];
   float out[4];
   float **w1;
   float ol[4];   // output layer
   float loss[4];
   float lr;
   int action;   // left(0), down(1), right(2), up(3)
   float gamma;
   float reward;
   float maxval;
   int done;
   int iteration;
   int s0, s1;
   int randcount;
   int success;

   nil = 16;
   nol = 4;

   lr = 0.1;

   w1 = (float**)calloc(nil, sizeof(float*));
   for(m=0; m<nil; m++){
      w1[m] = (float*)calloc(nol, sizeof(float));
   }

   srand((unsigned int)(time(0)));
   for(m=0; m<nil; m++){
      for(n=0; n<nol; n++){
         w1[m][n] = (float)(abs(rand()) / (RAND_MAX + 1.0)) / 100.0;
      }
      printf("[%d]: %f, %f, %f, %f\n", m, w1[m][0], w1[m][1], w1[m][2], w1[m][3]);
   }

   iteration = 10000;
   gamma = 0.98;
   success = 0;

   for(m=0; m<iteration; m++){
      done = 0;
      s0 = 0;
      s1 = 0;
      reward = 0.0;
      randcount = 10;

      while(!done){
         if(randcount > 5){
            memset(inp, 0, nil * sizeof(float));
            inp[s0] = 1.0;
            predict(w1, inp, out, ol, nil, nol);

            action = 0;
            if(out[0] < out[1]) action = 1;
            if(out[action] < out[2]) action = 2;
            if(out[action] < out[3]) action = 3;

            //printf("action:%d, out:%f, %f, %f, %f\n", action, out[0], out[1], out[2], out[3]);
         }
         else{
            action = random() % 4;
         }
         randcount--;
         if(!randcount) randcount = 10;

         /////////////////////////////////
         // setting from environment, game
         /////////////////////////////////

         reward = 0.0; done = 0;
         if(action == 0){
            if(s0==0 || s0==4 || s0==8 || s0==12){
               continue;
            }
         }
         else if(action == 1){
            if(s0==12 || s0==13 || s0==14 || s0==15){
               continue;
            }
         }
         else if(action == 2){
            if(s0==3 || s0==7 || s0==11 || s0==15){
               continue;
            }
         }
         else if(action == 3){
            if(s0==0 || s0==1 || s0==2 || s0==3){
               continue;
            }
         }

         if(action == 0) s1 = s0 - 1;
         else if(action == 1) s1 = s0 + 4;
         else if(action == 2) s1 = s0 + 1;
         else if(action == 3) s1 = s0 - 4;

         if(s1==5 || s1==7 || s1==11 || s1==12){   // at hole
            reward = -3.0;
            done = 1;
            //printf("s0:%d, s1:%d at hole\n", s0, s1);
         }
         else if(s1==15){   // at goal
            reward = 3.0;
            done = 1;
            success++;
            printf("[%d]: s0:%d, s1:%d at goal\n", m, s0, s1);
         }

         /////////////////////////////////
         /////////////////////////////////

         //if(!done) reward = -1.0;
         if(done==1 && reward==0) reward = -3.0;

      //if(success){
         memset(inp, 0, nil * sizeof(float));
         inp[s1] = 1.0;
         predict(w1, inp, out, ol, nil, nol);
         //printf("out: %f, %f, %f, %f\n", out[0], out[1], out[2], out[3]);

         maxval = out[0];
         if(maxval < out[1]) maxval = out[1];
         if(maxval < out[2]) maxval = out[2];
         if(maxval < out[3]) maxval = out[3];

         maxval = reward + (gamma * maxval);

         memset(inp, 0, nil * sizeof(float));
         inp[s0] = 1.0;
         predict(w1, inp, out, ol, nil, nol);

         memset(loss, 0, nol * sizeof(float));
         
         loss[action] = (maxval - out[action]);
         //printf("s0(%d), s1(%d), action(%d), reward:%f, maxval:%f, loss:%f\n", s0, s1, action, reward, maxval, loss[action]);

         memset(inp, 0, nil * sizeof(float));
         inp[s0] = 1.0;
         fit(inp, loss, w1, ol, lr, nil, nol);
      //}

         s0 = s1;
      }

   }

   printf("success:%d, %f percent, done!\n", success,
      (float)(((float)success / iteration) * 100.0));

   for(m=0; m<nil; m++){
      printf("[%d]: %f, %f, %f, %f\n", m, w1[m][0], w1[m][1], w1[m][2], w1[m][3]);
   }
}

