
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define MAXROW 10
#define MAXCOL 10

float sigmoid(float x){
   return 1 / ( 1 + expf(-x));
}

float diffsigmoid(float x){
   float y;
   y = 1 / (1 + expf(-x));
   return (y * (1 - y));
}

float relu(float x){
   return (x <= 0.0)? 0.0: x;
}

float diffrelu(float x){
   return (x <= 0.0)? 0.0: 1.0;
}

void predict(float **w1, float **w2, float *in, float *out,
   float *hl, float *ho, float *ol, int nil, int nhl, int nol){

   int m, n;

   for(m=0; m<nhl; m++){
      hl[m] = 0.0;
      for(n=0; n<nil; n++){
         hl[m] += (w1[n][m] * in[n]);
      }
      //ho[m] = sigmoid(hl[m]);
      ho[m] = relu(hl[m]);
   }

   for(m=0; m<nol; m++){
      ol[m] = 0.0;
      for(n=0; n<nhl; n++){
         ol[m] += (w2[n][m] * ho[n]);
      }
      //out[m] = sigmoid(ol[m]);
      out[m] = relu(ol[m]);
   }
}

void fit(float *in, float *loss, float **w1, float **w2,
   float *hl, float *ho, float *ol, float lr, int nil, int nhl, int nol){

   int m, n;
   float bp[nhl];
   float b1[nil][nhl];

   for(m=0; m<nhl; m++){
      bp[m] = 0.0;
      for(n=0; n<nol; n++){
         //bp[m] += (w2[m][n] * diffsigmoid(ol[n]) * loss[n]);
         bp[m] += (w2[m][n] * diffrelu(ol[n]) * loss[n]);
      }
   }

   for(m=0; m<nhl; m++){
      for(n=0; n<nil; n++){
         //b1[n][m] = (lr * in[n] * diffsigmoid(hl[m]) * bp[m]);
         b1[n][m] = (lr * in[n] * diffrelu(hl[m]) * bp[m]);
      }
   }

   for(m=0; m<nil; m++){
      for(n=0; n<nhl; n++){
         w1[m][n] = w1[m][n] + b1[m][n];
      }
   }
   for(m=0; m<nhl; m++){
      for(n=0; n<nol; n++){
         w2[m][n] = w2[m][n] + (lr * ho[m] * diffrelu(ol[n]) * loss[n]);;
      }
   }
}


void main(){
   int m, n;
   int nil, nhl, nol;
   float inp[16];
   float out[4];
   float **w1;
   float **w2;
   float hl[10];   // hdden layer
   float ho[10];   // output of hidden layer
   float ol[4];   // output layer
   float loss[4];
   float lr;
   int action;   // left(0), down(1), right(2), up(3)
   float gamma;
   float reward;
   float maxval;
   int done, barrier;
   int iteration;
   int s0, s1;
   int randcount;
   int success;
   int egr;
   float cost;
   int end;

   nil = 16;
   nhl = 10;
   nol = 4;

   w1 = (float**)calloc(nil, sizeof(float*));
   for(m=0; m<nil; m++){
      w1[m] = (float*)calloc(nhl, sizeof(float));
   }
   w2 = (float**)calloc(nhl, sizeof(float*));
   for(m=0; m<nhl; m++){
      w2[m] = (float*)calloc(nol, sizeof(float));
   }

   srand((unsigned int)(time(0)));
   for(m=0; m<nil; m++){
      for(n=0; n<nhl; n++){
         w1[m][n] = (float)(abs(rand()) / (RAND_MAX + 1.0)) / 100.0;
         //w1[m][n] = (float)(((float)rand() - ((float)RAND_MAX / 2.0)) / ((float)RAND_MAX + 1.0)) / 10.0;
      }
      //printf("w1:%f,%f, %f, %f, %f, %f, %f, %f, %f %f\n",
      //   w1[m][0], w1[m][1], w1[m][2], w1[m][3],
      //   w1[m][4], w1[m][5], w1[m][6], w1[m][7], w1[m][8], w1[m][9]);
   }
   for(m=0; m<nhl; m++){
      for(n=0; n<nol; n++){
         w2[m][n] = (float)(abs(rand()) / (RAND_MAX + 1.0)) / 100.0;
         //w2[m][n] = (float)(((float)rand() - ((float)RAND_MAX / 2.0)) / ((float)RAND_MAX + 1.0)) / 10.0;
      }
      //printf("w2:%f, %f, %f, %f\n", w2[m][0], w2[m][1], w2[m][2], w2[m][3]);
   }

   lr = 0.001;
   iteration = 0;
   gamma = 0.98;
   success = 0;
   cost = 0.0;
   end = 0;
   randcount = 10;
   egr = 7;

   //for(m=0; m<iteration; m++){
   while(!end){
      done = 0;
      s0 = 0;
      s1 = 0;
      reward = 0.0;

      while(!done){
         if(randcount > egr){
            memset(inp, 0, nil * sizeof(float));
            inp[s0] = 1.0;
            predict(w1, w2, inp, out, hl, ho, ol, nil, nhl, nol);

            action = 0;
            if(out[0] < out[1]) action = 1;
            if(out[action] < out[2]) action = 2;
            if(out[action] < out[3]) action = 3;

            //printf("action:%d, out:%f, %f, %f, %f\n", action, out[0], out[1], out[2], out[3]);
         }
         else{
            action = random() % 4;
         }
         randcount--;
         if(!randcount) randcount = 10;

         /////////////////////////////////
         // setting from environment, game
         /////////////////////////////////

         reward = 0.0; barrier = 0; done = 0;
         if(action == 0){
            if(s0==0 || s0==4 || s0==8 || s0==12){
               maxval = -3.0; done = 1; barrier = 1;
               //continue;
            }
         }
         else if(action == 1){
            if(s0==12 || s0==13 || s0==14 || s0==15){
               maxval = -3.0; done = 1; barrier = 1;
               //continue;
            }
         }
         else if(action == 2){
            if(s0==3 || s0==7 || s0==11 || s0==15){
               maxval = -3.0; done = 1; barrier = 1;
               //continue;
            }
         }
         else if(action == 3){
            if(s0==0 || s0==1 || s0==2 || s0==3){
               maxval = -3.0; done = 1; barrier = 1;
               //continue;
            }
         }

         if(!barrier){
            if(action == 0) s1 = s0 - 1;
            else if(action == 1) s1 = s0 + 4;
            else if(action == 2) s1 = s0 + 1;
            else if(action == 3) s1 = s0 - 4;

            if(s1==5 || s1==7 || s1==11 || s1==12){   // at hole
               reward = -3.0;
               done = 1;
               //printf("s0:%d, s1:%d at hole\n", s0, s1);
            }
            else if(s1==15){   // at goal
               reward = 3.0;
               done = 1;
               success++;

               //if(m > (int)(iteration * 0.99))
               //   printf("[%d]: s0:%d, s1:%d, action:%d at goal\n", iteration, s0, s1, action);
            }

            /////////////////////////////////
            /////////////////////////////////

            if(done==1 && reward==0) reward = -3.0;

            memset(inp, 0, nil * sizeof(float));
            inp[s1] = 1.0;
            predict(w1, w2, inp, out, hl, ho, ol, nil, nhl, nol);
            //printf("out: %f, %f, %f, %f\n", out[0], out[1], out[2], out[3]);

            maxval = out[0];
            if(maxval < out[1]) maxval = out[1];
            if(maxval < out[2]) maxval = out[2];
            if(maxval < out[3]) maxval = out[3];

            maxval = reward + (gamma * maxval);
         }   // barrier == 0

         memset(inp, 0, nil * sizeof(float));
         inp[s0] = 1.0;
         predict(w1, w2, inp, out, hl, ho, ol, nil, nhl, nol);

         memset(loss, 0, nol * sizeof(float));
         loss[action] = (maxval - out[action]);

         //printf("s0(%d), s1(%d), action(%d), reward:%f, maxval:%f, loss:%f\n", s0, s1, action, reward, maxval, loss[action]);

         memset(inp, 0, nil * sizeof(float));
         inp[s0] = 1.0;
         fit(inp, loss, w1, w2, hl, ho, ol, lr, nil, nhl, nol);

         if(success > 10000){
            //cost += powf(loss[action], 2.0);
            //printf("[%d]: loss:%f, cost:%f, out:%f, maxval:%f, action:%d\n", iteration, loss[action], cost, out[action], maxval, action);
            if(s1==15 && loss[action] < 0.0001 && loss[action] > -0.0001){
               printf("[%d]: loss:%f, cost:%f, out:%f, maxval:%f, action:%d\n", iteration, loss[action], cost, out[action], maxval, action);
               end = 1;
            }
         }
         s0 = s1;
      }
      iteration++;

   }

   printf("success:%d, %f percent, done!\n", success,
      (float)(((float)success / iteration) * 100.0));

   //for(m=0; m<nil; m++){
   //   printf("w1[%d]:%f,%f, %f, %f\n", m, w1[m][0], w1[m][1], w1[m][2], w1[m][3]);
   //}
   //for(m=0; m<nhl; m++){
   //   printf("w2[%d]:%f,%f, %f, %f\n", m, w2[m][0], w2[m][1], w2[m][2], w2[m][3]);
   //}

   for(m=0; m<20; m++){
      s0 = 0;
      s1 = 0;
      done = 0;
      n=0;
      while(!done){
         memset(inp, 0, nil * sizeof(float));
         inp[s0] = 1.0;
         predict(w1, w2, inp, out, hl, ho, ol, nil, nhl, nol);

         action = 0;
         if(out[0] < out[1]) action = 1;
         if(out[action] < out[2]) action = 2;
         if(out[action] < out[3]) action = 3;

         printf("%d(%d)->", s0, action);
         if(n++ > 10) break;

         done = 0;
         if(action == 0){
            if(s0==0 || s0==4 || s0==8 || s0==12){
               s0 = 0;
               continue;
            }
         }
         else if(action == 1){
            if(s0==12 || s0==13 || s0==14 || s0==15){
               s0 = 0;
               continue;
            }
         }
         else if(action == 2){
            if(s0==3 || s0==7 || s0==11 || s0==15){
               s0 = 0;
               continue;
            }
         }
         else if(action == 3){
            if(s0==0 || s0==1 || s0==2 || s0==3){
               s0 = 0;
               continue;
            }
         }

         if(action == 0) s1 = s0 - 1;
         else if(action == 1) s1 = s0 + 4;
         else if(action == 2) s1 = s0 + 1;
         else if(action == 3) s1 = s0 - 4;

         if(s1==5 || s1==7 || s1==11 || s1==12){   // at hole
            done = 1;
            printf("s0:%d, s1:%d at hole\n", s0, s1);
         }
         else if(s1==15){   // at goal
            done = 1;
            printf("[%d]: s0:%d, s1:%d, action:%d at goal\n", m, s0, s1, action);
         }
         s0 = s1;
      }
   }

}

