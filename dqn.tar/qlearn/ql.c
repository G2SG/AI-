
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void main(){
   int m, n;
   float qtable[16][4];
   int action;   // left(0), down(1), right(2), up(3)
   float gamma;
   float reward;
   float maxval;
   int done;
   int iteration;
   int state;
   int next_state;
   int randcount;

   memset(&qtable[0][0], 0, 16*4*sizeof(float));
   qtable[0][0] = -1.0;
   qtable[0][3] = -1.0;
   qtable[1][3] = -1.0;
   qtable[2][3] = -1.0;
   qtable[3][2] = -1.0;
   qtable[3][3] = -1.0;
   qtable[4][0] = -1.0;
   qtable[7][2] = -1.0;
   qtable[8][0] = -1.0;
   qtable[11][2] = -1.0;
   qtable[12][0] = -1.0;
   qtable[12][1] = -1.0;
   qtable[13][1] = -1.0;
   qtable[14][1] = -1.0;
   //qtable[14][2] = 1.0;
   qtable[15][1] = -1.0;
   qtable[15][2] = -1.0;

   iteration = 50;
   gamma = 0.98;

   for(m=0; m<iteration; m++){
      done = 0;
      state = 0;
      next_state = 0;
      reward = 0.0;
      randcount = 10;

      while(!done){
         if(randcount > 5){
            action = 0;
            if(qtable[state][0] < qtable[state][1]) action = 1;
            if(qtable[state][action] < qtable[state][2]) action = 2;
            if(qtable[state][action] < qtable[state][3]) action = 3;
         }
         else{
            while(1){
               action = random() % 4;
               if(qtable[state][action] >= 0.0) break;
            }
         }

         if(!randcount--) randcount = 10;

         if(action == 0) next_state = state - 1;
         else if(action == 1) next_state = state + 4;
         else if(action == 2) next_state = state + 1;
         else if(action == 3) next_state = state - 4;
         
         //if(next_state<0 || next_state>15) next_state = state;

         maxval = qtable[next_state][0];
         if(maxval < qtable[next_state][1]) maxval = qtable[next_state][1];
         if(maxval < qtable[next_state][2]) maxval = qtable[next_state][2];
         if(maxval < qtable[next_state][3]) maxval = qtable[next_state][3];

         if(next_state==5 || next_state==7 || next_state==11 || next_state==12){
            qtable[state][action] = -1.0;
            done = 1;
            printf("state:%d, action:%d, next_state:%d, qt:%f at hole\n",
               state, action, next_state, qtable[state][action]);
         }
         else if(next_state==15){
            //reward = 1.0;
            qtable[state][action] = 1.0 + (gamma * maxval);
            done = 1;
            printf("state:%d, action:%d, next_state:%d, qt:%f at goal\n",
               state, action, next_state, qtable[state][action]);
         }
         else{
            // reward = 0.0
            qtable[state][action] = (gamma * maxval);
            //printf("state:%d, action:%d, next_state:%d, qt:%f at progress\n",
            //   state, action, next_state, qtable[state][action]);
         }

         state = next_state;
      }
   }

   for(m=0; m<16; m++){
      printf("state[%d]: ", m);
      printf("%f, %f, %f, %f\n", qtable[m][0], qtable[m][1], qtable[m][2], qtable[m][3]);
   }

   printf("done!\n");

}

